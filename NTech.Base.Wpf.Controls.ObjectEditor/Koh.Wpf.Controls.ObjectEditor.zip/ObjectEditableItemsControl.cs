﻿using Koh.Wpf.Controls.ObjectEditor.Adorners;
using Koh.Wpf.Controls.ObjectEditor.Models;
using Koh.Wpf.Foundation.Helper;
using Koh.Wpf.Foundation.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace Koh.Wpf.Controls.ObjectEditor
{
    public class ObjectEditableItemsControl : ItemsControl
    {
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new ContentControl();
        }
        #region Drag Drop
        private Point _downPoint;
        private Point _donwPointOffset;
        private FrameworkElement _downContainer;
        private DateTime _downContainerCapturedTime;

        protected override void OnPreviewMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            var container = CaptureContainer(e);
            if (container != null)
            {
                ObjectEditableItemsControlHelper.SetSelect(this, container, Keyboard.IsKeyDown(Key.LeftCtrl));
                e.Handled = true;
            }
        }

        

        protected override void OnPreviewMouseUp(MouseButtonEventArgs e)
        {
            this.ReleaseMouseCapture();
            _downContainer = null;
        }

        MoveAdorner _moveAdorner;
        protected override void OnPreviewMouseMove(MouseEventArgs e)
        {
            if (_downContainer != null && Mouse.LeftButton == MouseButtonState.Pressed && Mouse.Captured == this)
            {
                if ((DateTime.Now - _downContainerCapturedTime).TotalSeconds > 0.1d)
                {
                    if (_downContainer != null)
                    {
                        try
                        {
                            var layoutPanel = GetItemsPanel();

                            var selectedItems = ObjectEditableItemsControlHelper.GetSelectedContainer(this);
                            _moveAdorner = new MoveAdorner(layoutPanel, _downContainer, selectedItems, _downPoint, _donwPointOffset);

                            ObjectEditableItemsControlHelper.SetContainerVisibility(selectedItems, Visibility.Hidden);


                            AdornerLayer.GetAdornerLayer(layoutPanel as Visual).Add(_moveAdorner);

                            DragDrop.AddGiveFeedbackHandler(layoutPanel, new GiveFeedbackEventHandler(DragDrop_Feedback));
                            DragDrop.AddQueryContinueDragHandler(layoutPanel, new QueryContinueDragEventHandler(DragDrop_QueryContinueDrag));

                            DragDrop.DoDragDrop(layoutPanel, new object(), DragDropEffects.None);

                            DragDrop.RemoveQueryContinueDragHandler(layoutPanel, new QueryContinueDragEventHandler(DragDrop_QueryContinueDrag));
                            DragDrop.RemoveGiveFeedbackHandler(layoutPanel, new GiveFeedbackEventHandler(DragDrop_Feedback));

                            AdornerLayer.GetAdornerLayer(layoutPanel as Visual).Remove(_moveAdorner);

                            ObjectEditableItemsControlHelper.SetContainerVisibility(selectedItems, Visibility.Visible);
                        }
                        catch
                        {
                        }
                        finally
                        {
                            _moveAdorner = null;
                        }
                    }
                }
            }
        }

        private void DragDrop_Feedback(object sender, GiveFeedbackEventArgs e)
        {
            if (_moveAdorner != null)
            {
                var point = this.PointFromScreen(User32Util.GetMousePosition());
                _moveAdorner.UpdatePosition(point);
            }
            e.Handled = true;
        }
        private void DragDrop_QueryContinueDrag(object sender, QueryContinueDragEventArgs e)
        {
            //if (e.EscapePressed == true)
            //{
            //    _isAdornerCancel = true;
            //}
        }

        private FrameworkElement CaptureContainer(MouseButtonEventArgs e)
        {
            var fe = e.OriginalSource as FrameworkElement;
            if (fe != null)
            {
                var container = this.ItemContainerGenerator.ContainerFromItem(fe.DataContext) as FrameworkElement;
                if (container != null)
                {
                    _downContainer = container;
                    _downPoint = e.GetPosition(GetItemsPanel());
                    var pos = e.GetPosition(_downContainer);
                    _donwPointOffset = new Point(-pos.X, -pos.Y);
                    _downContainerCapturedTime = DateTime.Now;

                    Mouse.Capture(this);
                }
                return container;
            }
            return null;
        }


        #endregion


        private Panel GetItemsPanel()
        {
            ItemsPresenter itemsPresenter = VisualTreeHelperEx.FindDescendantByType<ItemsPresenter>(this);
            Panel itemsPanel = VisualTreeHelper.GetChild(itemsPresenter, 0) as Panel;
            return itemsPanel;
        }
    }
}
