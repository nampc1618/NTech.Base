﻿using Koh.Wpf.Controls.ObjectEditor.Models;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ObjectEditorTest
{
    public class EditableUIObjectBase : BindableBase, IEditableUIObject
    {
        public bool IsSelected
        {
            get
            {
                return _isSelected;
            }
            set
            {
                _isSelected = value;
                RaisePropertyChanged();
            }
        }
        private bool _isSelected;

        public double X
        {
            get
            {
                return this.OverrideX == null ? _x : (double)this.OverrideX;
            }
            set
            {
                _x = value;
                RaisePropertyChanged();
            }
        }
        private double _x;

        public double Y
        {
            get
            {
                return this.OverrideY == null ? _y : (double)this.OverrideY;
            }
            set
            {
                _y = value;
                RaisePropertyChanged();
            }
        }
        private double _y;

        public double Width
        {
            get
            {
                return this.OverrideWidth == null ? _width : (double)this.OverrideWidth;
            }
            set
            {
                _width = value;
                RaisePropertyChanged();
            }
        }
        private double _width;

        public double Height
        {
            get
            {
                return this.OverrideHeight == null ? _height : (double)this.OverrideHeight;
            }
            set
            {
                _height = value;
                RaisePropertyChanged();
            }
        }
        private double _height;

        public int ZIndex
        {
            get
            {
                return this.OverrideZIndex == null ? _zIndex : (int)this.OverrideZIndex;
            }
            set
            {
                _zIndex = value;
                RaisePropertyChanged();
            }
        }
        private int _zIndex;

        public double? OverrideX
        {
            get
            {
                return _overrideX;
            }
            set
            {
                _overrideX = value;
                RaisePropertyChanged("X");
            }
        }
        private double? _overrideX;

        public double? OverrideY
        {
            get
            {
                return _overrideY;
            }
            set
            {
                _overrideY = value;
                RaisePropertyChanged("Y");
            }
        }
        private double? _overrideY;

        public double? OverrideWidth
        {
            get
            {
                return _overrideWidth;
            }
            set
            {
                _overrideWidth = value;
                RaisePropertyChanged("Width");
            }
        }
        private double? _overrideWidth;

        public double? OverrideHeight
        {
            get
            {
                return _overrideHeight;
            }
            set
            {
                _overrideHeight = value;
                RaisePropertyChanged("Height");
            }
        }
        private double? _overrideHeight;

        public int? OverrideZIndex
        {
            get
            {
                return _overrideZIndex;
            }
            set
            {
                _overrideZIndex = value;
                RaisePropertyChanged("ZIndex");
            }
        }
        private int? _overrideZIndex;



        public bool IsOverride { get; private set; }

        public virtual void BeginOverridePosition()
        {
            this.IsOverride = true;
            this.OverrideX = this.X;
            this.OverrideY = this.Y;
            this.OverrideWidth = this.Width;
            this.OverrideHeight = this.Height;
            this.OverrideZIndex = this.ZIndex;
        }

        public virtual void EndOverridePosition(bool isCancel)
        {
            if (isCancel == false)
            {
                this.X = (double)this.OverrideX;
                this.Y = (double)this.OverrideY;
                this.Width = (double)this.OverrideWidth;
                this.Height = (double)this.OverrideHeight;
                //this.ZIndex = (int)this.OverrideZIndex;
            }
            this.IsOverride = false;

            this.OverrideX = null;
            this.OverrideY = null;
            this.OverrideWidth = null;
            this.OverrideHeight = null;
            this.OverrideZIndex = null;
        }

        public virtual Rect GetBounds()
        {
            return new Rect(_x, _y, _width, _height);
        }
    }
}
