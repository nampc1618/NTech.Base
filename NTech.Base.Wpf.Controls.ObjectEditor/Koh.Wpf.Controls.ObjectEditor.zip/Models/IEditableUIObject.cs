﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Koh.Wpf.Controls.ObjectEditor.Models
{
    public interface IEditableUIObject
    {
        // Positions
        double X { get; set; }
        double Y { get; set; }
        double Width { get; set; }
        double Height { get; set; }
        int ZIndex { get; set; }

        double? OverrideX { get; set; }
        double? OverrideY { get; set; }
        double? OverrideWidth { get; set; }
        double? OverrideHeight { get; set; }
        int? OverrideZIndex { get; set; }

        bool IsOverride { get; }

        void BeginOverridePosition();
        void EndOverridePosition(bool isCancel);

        Rect GetBounds();

        // Selections
        bool IsSelected { get; set; }
    }
}
