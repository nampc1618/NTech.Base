﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Koh.Wpf.Controls.ObjectEditor.Adorners
{
    public class MoveAdorner : Adorner
    {
        private FrameworkElement _baseElement;
        private Point _startPoint;
        private Point _movedPoint;
        private Point _startPointOffset;
        private Dictionary<FrameworkElement, VisualBrush> _elementBrushes;
        private List<FrameworkElement> _elements;


        public MoveAdorner(UIElement adornerElement, FrameworkElement baseElement, List<FrameworkElement> elements, Point startPoint, Point startPointOffset)
            : base(adornerElement)
        {
            _baseElement = baseElement;
            _startPoint = startPoint;
            _movedPoint = startPoint;
            _startPointOffset = startPointOffset;

            if (elements == null)
            {
                elements = new List<FrameworkElement>();
                elements.Add(baseElement);
            }

            _elementBrushes = new Dictionary<FrameworkElement, VisualBrush>();
            if (elements != null)
            {
                foreach (var element in elements)
                {
                    var fc = Foundation.Helper.VisualTreeHelperEx.FindDescendantByType<Grid>(baseElement);
                    var content = fc;
                    var brush = new VisualBrush(content);
                    if (_elementBrushes.ContainsKey(element) == false)
                    {
                        _elementBrushes.Add(element, brush);
                    }
                }
            }
            _elements = elements;
        }

        public void UpdatePosition(Point position)
        {
            _movedPoint = position;
            this.InvalidateVisual();
        }

        protected override void OnRender(DrawingContext dc)
        {
            base.OnRender(dc);

            var gap = _movedPoint - _startPoint;
            double x = _startPoint.X + gap.X + _startPointOffset.X;
            double y = _startPoint.Y + gap.Y + _startPointOffset.Y;
            double width = _baseElement.ActualWidth;
            double height = _baseElement.ActualHeight;

            foreach (var element in _elements)
            {
                if(_elementBrushes.ContainsKey(element) == true)
                {
                    var brush = _elementBrushes[element];

                    if (_baseElement != element)
                    {
                        var eGap = element.TranslatePoint(new Point(), _baseElement);

                        var ex = x + eGap.X;
                        var ey = y + eGap.Y;
                        width = element.ActualWidth;
                        height = element.ActualHeight;
                        dc.DrawRectangle(brush, new Pen(Brushes.Red, 3), new Rect(ex, ey, width, height));
                    }
                    else
                    {
                        dc.DrawRectangle(brush, new Pen(Brushes.Pink, 3), new Rect(x, y, width, height));
                    }
                }
            }
        }
    }
}
