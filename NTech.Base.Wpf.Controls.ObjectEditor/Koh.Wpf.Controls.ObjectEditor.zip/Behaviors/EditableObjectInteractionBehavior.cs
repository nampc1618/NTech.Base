﻿using Koh.Wpf.Controls.ObjectEditor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interactivity;

namespace Koh.Wpf.Controls.ObjectEditor.Behaviors
{
    public class EditableObjectInteractionBehavior : Behavior<UIElement>
    {
        public class ObjectTransitionArgs : EventArgs
        {
            public List<ObjectTransitionToMoveInfo> MovedTargets { get; set; }
        }

        public class ObjectTransitionToMoveInfo
        {
            public IEditableUIObject Item { get; set; }
            public Point OriginPosition { get; set; }
            public Point MovedOffset { get; set; }

            public bool Handled { get; set; }
        }

        public double DragThreshold
        {
            get { return (double)GetValue(DragThresholdProperty); }
            set { SetValue(DragThresholdProperty, value); }
        }
        public static readonly DependencyProperty DragThresholdProperty =
            DependencyProperty.Register("DragThreshold", typeof(double), typeof(EditableObjectInteractionBehavior), new PropertyMetadata(5d));


        public UIElement ParentElement
        {
            get { return (UIElement)GetValue(ParentElementProperty); }
            set { SetValue(ParentElementProperty, value); }
        }
        public static readonly DependencyProperty ParentElementProperty =
            DependencyProperty.Register("ParentElement", typeof(UIElement), typeof(EditableObjectInteractionBehavior));


        public object ItemsSource
        {
            get { return (object)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }
        public static readonly DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(object), typeof(EditableObjectInteractionBehavior));



        private FrameworkElement _element;

        protected override void OnAttached()
        {
            base.OnAttached();

            _element = this.AssociatedObject as FrameworkElement;
            AttatchedEvents();
        }

        protected override void OnDetaching()
        {
            _element = null;

            base.OnDetaching();
        }

        private void AttatchedEvents()
        {
            if (_element == null)
            {
                return;
            }

            _element.PreviewMouseLeftButtonDown += _element_PreviewMouseLeftButtonDown;
            _element.PreviewMouseMove += _element_PreviewMouseMove;
            _element.PreviewMouseLeftButtonUp += _element_PreviewMouseLeftButtonUp;
        }

        private Point _downPoint;
        private FrameworkElement _downElement;

        private void _element_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (IsReadyProperties() == false)
            {
                return;
            }

            _downPoint = e.GetPosition(ParentElement);
            _downElement = e.OriginalSource as FrameworkElement;

            SetSelect();

            _element.CaptureMouse();
            e.Handled = true;
        }

        private IEditableUIObject GetModelFromDownElement()
        {
            if (_downElement == null)
            {
                return null;
            }
            return _downElement.DataContext as IEditableUIObject;
        }

        private void SetSelect()
        {
            var model = GetModelFromDownElement();
            if (model != null)
            {
                if (model.IsSelected == false)
                {
                    var items = this.ItemsSource as System.Collections.ICollection;
                    if (items != null)
                    {
                        foreach (var item in items.OfType<IEditableUIObject>())
                        {
                            item.IsSelected = false;
                        }
                    }
                    model.IsSelected = true;
                }
            }
        }

        private void _element_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (IsReadyProperties() == false || _downElement == null)
            {
                return;
            }

            if (Mouse.LeftButton == MouseButtonState.Pressed && _element.IsMouseCaptured == true)
            {
                var pos = e.GetPosition(ParentElement);
                var gap = pos - _downPoint;
                System.Diagnostics.Debug.WriteLine(gap);
                if (gap.Length >= this.DragThreshold)
                {
                    // Do Drag
                    var model = GetModelFromDownElement();
                    if (model != null)
                    {
                        if (model.IsOverride == false)
                        {
                            model.BeginOverridePosition();
                            model.OverrideZIndex = int.MaxValue;
                        }

                        var bounds = model.GetBounds();

                        ObjectTransitionArgs args = new ObjectTransitionArgs();
                        args.MovedTargets = new List<ObjectTransitionToMoveInfo>();
                        args.MovedTargets.Add(new ObjectTransitionToMoveInfo()
                        {
                            Item = model,
                            OriginPosition = bounds.Location,
                            MovedOffset = new Point(gap.X, gap.Y)
                        });

                        //if (ObjectMoving == null)
                        //{
                        //    model.OverrideX = bounds.X + gap.X;
                        //    model.OverrideY = bounds.Y + gap.Y;
                        //}
                        //else
                        //{
                        //    ObjectMoving(model, bounds.Location, new Point(gap.X, gap.Y));
                        //}

                        if (ObjectMoving != null)
                        {
                            ObjectMoving(this, args);
                        }

                        foreach (var a in args.MovedTargets)
                        {
                            if (a.Handled == false)
                            {
                                a.Item.OverrideX = a.OriginPosition.X + a.MovedOffset.X;
                                a.Item.OverrideY = a.OriginPosition.Y + a.MovedOffset.Y;
                            }
                        }
                    }
                }

                e.Handled = true;
            }
        }

        private void _element_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (IsReadyProperties() == false)
            {
                return;
            }

            var model = GetModelFromDownElement();
            if (model != null)
            {
                if (model.IsOverride == true)
                {
                    model.EndOverridePosition(false);
                }
            }

            _element.ReleaseMouseCapture();
            _downElement = null;
            e.Handled = true;
        }

        public event EventHandler<ObjectTransitionArgs> ObjectMoving;

        public bool IsReadyProperties()
        {
            if (_element == null)
            {
                return false;
            }

            if (ParentElement == null)
            {
                return false;
            }


            return true;
        }
    }
}
